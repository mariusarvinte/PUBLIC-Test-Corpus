empty target clone
